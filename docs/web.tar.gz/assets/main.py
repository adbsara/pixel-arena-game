# /// script
# dependencies = [
#   "numpy",
#   "pygame-ce",
# ]
# ///
import asyncio

import numpy
import pygame

from pixel_arena.ui.play import main

asyncio.run(main())
